buildscript {
    repositories {
        google()
        mavenCentral()
    }

    dependencies {
        classpath("com.android.tools.build:gradle:8.6.0") // Use a stable version compatible with compileSdk 34
        classpath("com.google.gms:google-services:4.4.2") // Ensure this is the latest version available
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}