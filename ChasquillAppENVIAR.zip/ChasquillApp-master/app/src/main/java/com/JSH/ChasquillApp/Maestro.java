package com.JSH.ChasquillApp;

public class Maestro {
    public String nombre;
    public String servicios;

    public Maestro() {} // Constructor vacío requerido por Firebase

    public Maestro(String nombre, String servicios) {
        this.nombre = nombre;
        this.servicios = servicios;
    }
}