package com.JSH.ChasquillApp;

import android.content.Context;
import android.util.Log;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;

public class MqttService {

    private static final String TAG = "MqttService";
    private MqttAndroidClient mqttClient;

    public MqttService(Context context, String brokerUrl) {
        mqttClient = new MqttAndroidClient(context.getApplicationContext(), brokerUrl, MqttAndroidClient.generateClientId());
    }

    public void connect(String username, String password) {
        MqttConnectOptions options = new MqttConnectOptions();
        options.setUserName(username);
        options.setPassword(password.toCharArray());
        options.setCleanSession(true);

        try {
            mqttClient.connect(options, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.i(TAG, "Conectado al Broker MQTT");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e(TAG, "Error al conectar al Broker MQTT", exception);
                }
            });
        } catch (MqttException e) {
            Log.e(TAG, "Error conectando al Broker MQTT", e);
        }
    }

    public void publish(String topic, String message) {
        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            mqttMessage.setQos(0);
            mqttClient.publish(topic, mqttMessage);
            Log.i(TAG, "Mensaje publicado: " + message);
        } catch (MqttException e) {
            Log.e(TAG, "Error al publicar mensaje", e);
        }
    }

    public void subscribe(String topic) {
        try {
            mqttClient.subscribe(topic, 0);
            Log.i(TAG,"Suscrito al tópico: " + topic);
        } catch (MqttException e) {
            Log.e(TAG,"Error al suscribirse al tópico", e);
        }
    }

    public void setCallback(MqttCallback callback) {
        mqttClient.setCallback(callback);
    }
}