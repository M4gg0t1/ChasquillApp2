package com.JSH.ChasquillApp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminModeActivity extends AppCompatActivity {

    private EditText editTextName, editTextRepairs, editTextBaseValue;
    private MqttService mqttService; // Añadir esta línea

    // Inicializa la referencia a la base de datos
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Maestros");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_mode);

        editTextName = findViewById(R.id.editTextName);
        editTextRepairs = findViewById(R.id.editTextRepairs);
        editTextBaseValue = findViewById(R.id.editTextBaseValue);

        Button buttonRegisterMaster = findViewById(R.id.buttonRegisterMaster);

        // Inicializa el servicio MQTT
        mqttService = new MqttService(this, "tcp://broker.hivemq.com:1883"); // Cambia a tu broker

        buttonRegisterMaster.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerMaster();
            }
        });
    }

    private void registerMaster() {
        String name = editTextName.getText().toString().trim();
        String repairs = editTextRepairs.getText().toString().trim();
        String baseValue = editTextBaseValue.getText().toString().trim();

        // Validación simple para asegurarse de que los campos no estén vacíos
        if (name.isEmpty() || repairs.isEmpty() || baseValue.isEmpty()) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear un nuevo objeto Maestro
        Maestro nuevoMaestro = new Maestro(name, repairs + " - $" + baseValue);

        // Guardar los datos en la base de datos
        String id = databaseReference.push().getKey(); // Genera un ID único
        if (id != null) {
            databaseReference.child(id).setValue(nuevoMaestro)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Maestro registrado exitosamente", Toast.LENGTH_SHORT).show();
                        // Limpiar campos después de registrar
                        editTextName.setText("");
                        editTextRepairs.setText("");
                        editTextBaseValue.setText("");

                        // Publicar mensaje MQTT
                        String topic = "maestros/nuevo"; // Define tu tópico aquí
                        String message = "Nuevo Maestro: " + name + ", Servicios: " + repairs + " - $" + baseValue;
                        mqttService.publish(topic, message); // Publicar el mensaje
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error al registrar maestro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }
}