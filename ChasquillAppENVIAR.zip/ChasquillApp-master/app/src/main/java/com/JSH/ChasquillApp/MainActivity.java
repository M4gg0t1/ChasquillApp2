package com.JSH.ChasquillApp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private MqttService mqttService; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa el servicio MQTT aquí si es necesario.
        mqttService = new MqttService(this, "tcp://broker.hivemq.com:1883"); // Cambia a tu broker

        Button btnAdminMode = findViewById(R.id.buttonAdminMode);
        btnAdminMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica para entrar en modo administrador o iniciar AdminModeActivity.
            }
        });
    }
}