package com.JSH.ChasquillApp;

public class Cliente {
    public String correo;
    public String contraseña;
    public String numero;

    public Cliente() {} // Constructor vacío requerido por Firebase

    public Cliente(String correo, String contraseña, String numero) {
        this.correo = correo;
        this.contraseña = contraseña;
        this.numero = numero;
    }
}